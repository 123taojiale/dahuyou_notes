console.log("我是b模块");
module.exports = "b"