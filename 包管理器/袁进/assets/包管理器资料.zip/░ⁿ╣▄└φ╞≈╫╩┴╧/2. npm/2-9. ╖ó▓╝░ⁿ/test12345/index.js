var _ = require("lodash");

module.exports = function (arr) {
    return _.compact(arr);
}