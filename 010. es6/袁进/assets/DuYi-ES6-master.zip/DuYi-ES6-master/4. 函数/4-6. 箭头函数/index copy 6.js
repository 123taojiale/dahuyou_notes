const func = () => {
    console.log(this)
}
