const text = "成哥是狠人";


console.log("是否包含“狠”：", text.includes("狠"));
console.log("是否以“成哥”开头：", text.startsWith("成哥"));
console.log("是否以“狠人”结尾：", text.endsWith("狠人"));
console.log("重复4次：", text.repeat(4));