console.log("Hello NodeJs");//是不是ES标准
setInterval(function(){
    console.log("Hello")
}, 1000)