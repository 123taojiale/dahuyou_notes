console.log("b模块运行了")

export var b = 123;