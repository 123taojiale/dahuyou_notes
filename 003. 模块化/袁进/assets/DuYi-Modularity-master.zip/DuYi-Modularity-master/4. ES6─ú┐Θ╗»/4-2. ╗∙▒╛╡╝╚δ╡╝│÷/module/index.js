import "./b.js";
import "./init.js"
import * as a from "./a.js"

// var b = 3;
// console.log(b2)
// console.log(name, age);
// console.log(b)

console.log(a.a, a.age, a.name)