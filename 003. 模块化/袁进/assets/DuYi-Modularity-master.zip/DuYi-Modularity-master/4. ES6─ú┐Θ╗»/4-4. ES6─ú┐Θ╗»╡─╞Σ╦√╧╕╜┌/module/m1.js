export const a = "m1-a";
export const b = "m1-b";
export const c = "m1-c";

export default "m1-default";

/*
{
    a:xx,
    b:xx,
    c:xx,
    default:xxx
}
*/