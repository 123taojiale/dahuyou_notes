Array.prototype.print = function () {
    console.log(this);
}

//一些其他的代码